This set of MATLAB files contain an implementation of the algorithm for image deblurring described in the following paper:

Benxin Zhang, Guopu Zhu, Zhibin Zhu, Sam Kwong, Alternating direction method of multipliers for nonconvex log total  variation image restoration, 
Applied Mathematical Modelling, 2023, 114: 338–359.
 

 