
clear
clc

for iii =2
    switch iii
        case 1
            f = imread('Parrots256.tif'); 
            
            forg = double(f)/255; 
        case 2
             f = imread('8.bmp'); 
             forg =double(f)/255; 
           
            
             
             
           
    end    
    
    
         %psf   = fspecial('average',[3 3]);   
         psf   =  fspecial('gaussian',3,10); 
       
       
       
  
            ftrue = forg;          
            H     = BlurMatrix(psf,size(ftrue));
            gblur = H * ftrue;  
          
            g=imnoise(gblur,'gaussian',0,.01);
           
          
           figure (7)
          imshow(g,[])    



     
            
            
            
           
             %% logtv
              F=g;
              Org=forg;
              mu=360;
              t=cputime;
              outlogtv=logtvADM(H,F,mu);%ADM2TVL1a
              tlogtv=cputime-t;
   
              elogtv=norm(outlogtv.sol-Org)/norm(Org);
              figure (2)
              imshow(outlogtv.sol,[])

             figure (9)
            plot(outlogtv.itr,outlogtv.obj,'r-.','linewidth',3);
           
            set(gca,'FontSize',18);
            xlabel('Iterations','FontSize',20);
             ylabel('Objective Values','FontSize',20);
               
    
    
             PSNRlogtv=PSNR(Org,outlogtv.sol);
  
    
            
               figure (8)
               imshow(forg,[])

               
              
end