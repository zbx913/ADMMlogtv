
clear
clc

for iii =2
    switch iii
        case 1
            f = imread('Parrots256.tif'); 
            
            forg = double(f)/255; 
        case 2
             f = imread('8.bmp'); 
             forg =double(f)/255; 
           
            
             
             
           
    end    
    
    
         psf   = fspecial('average',[3 3]);   
         %psf   =  fspecial('gaussian',3,10); 
       
       
       
  
            ftrue = forg;          
            H     = BlurMatrix(psf,size(ftrue));
            gblur = H * ftrue;  
          
            g=imnoise(gblur,'gaussian',0,.01);
           
          
         



     
            
            
            
           
             %% logtv
              F=g;
              Org=forg;
              mu=360;
              t=cputime;
              outlogtv=logtvADM(H,F,mu);%ADM2TVL1a
              tlogtv=cputime-t;
   
              elogtv=norm(outlogtv.sol-Org)/norm(Org);
              PSNRlogtv=PSNR(Org,outlogtv.sol);

          
           
               figure (1)
               imshow(forg,[])
                
               figure (2)
               imshow(g,[])    
               figure (3)
               imshow(outlogtv.sol,[])
              
end