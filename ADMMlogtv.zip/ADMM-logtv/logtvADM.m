function out = logtvADM(H,F,mu,opts)
%
% Alternating Directions Method of Multipliers (ADMM) applied to logTV.
% 
%
% 
% ***     min_x rlog(1+ ||Dx||_1/a) + mu/2*||K*x - F||_2      ***
% 
% Inputs:
%         H  ---  convolution kernel 
%         F  ---  blurry and noisy observation
%         mu ---  model prameter (must be provided by user)
%         opts --- a structure containing algorithm parameters {default}
%                 * opst.beta   : a positive constant 
%                 
%                 * opst.gamma   : a constant >1
%                 * opst.maxitr  : maximum iteration number 
%                 * opst.relchg  : a small positive parameter which controls
%                                  stopping rule of the code. When the
%                                  relative change of X is less than
%                                  opts.relchg, then the code stops. {1.e-3}
%                 
% 
% Outputs:
%         out --- a structure contains the following fields
%                
%                
%               
%                
%                * out.relchg: the history of relative change in X
%                * out.sol   : numerical solution obtained by this code
%                * out.itr   : number of iterations used



%% initialization
[m, n] = size(F);

if nargin < 5; opts = []; end
opts = getopts(opts);


 a=600;
 r=10000;

X = F;
Lam1 = zeros(m,n);
Lam2 = Lam1;
beta = opts.beta;
gamma = opts.gamma;




psf = [0;-1;1];
Dx  = BlurMatrix(psf, size(F));
Dy  = BlurMatrix(psf', size(F));

HtH =H' * H;
DtD  =Dx' * Dx + Dy' * Dy;




%% finite diff
D1X=Dx*X;
D2X=Dy*X;


out.itr=[];
out.relchg = [];


%% Main loop
for i = 1:opts.maxitr
   Xp=X;
    
    % ==================
    %   Shrinkage Step
    % ==================
    V1 = D1X + Lam1/beta;
    V2 = D2X + Lam2/beta;
   
    a1=sign(V1)/2;
    a2=sign(V2)/2;
    b1=abs(V1)-a;
    b2=abs(V2)-a;
    c1=a*abs(V1)-r/beta;
    c2=a*abs(V2)-r/beta;
    d1=max(0,c1);
    d2=max(0,c2); 
    
    Y1=a1.*(b1+sqrt((-b1).^2+4*d1));
    Y2=a2.*(b2+sqrt((-b2).^2+4*d2));

    % ==================
    %     X-subprolem
    % ==================
  
    
   
   
    
    X = Dx'*(beta*Y1 - Lam1)+Dy'*(beta*Y2 - Lam2)+mu*H'*F ;
    

    Denom= inv(mu*HtH +beta* DtD);
    X = Denom*X;
    D1X=Dx*X;
    D2X=Dy*X;

    relchg = norm(X - Xp,'fro')/norm(X,'fro');
    out.relchg = [out.relchg; relchg];

   
    out.itr=[out.itr,i];
    % ====================
    % Check stopping rule
    % ====================
   
if relchg < opts.relchg
        out.sol = X;
       
        return
end
    
    
   

    % ==================
    %    Update Lam
    % ==================
   
    
    Lam1 = Lam1 +beta*(D1X-Y1);
    Lam2 = Lam2 +beta*(D2X-Y2);
    beta=gamma*beta;

end

out.sol = X;
out.exit = 'Exist Normally';
if i == opts.maxitr
    out.exit = 'Maximum iteration reached!';
end

    
%% ------------------SUBFUNCTION-----------------------------
function opts = getopts(opts)

if ~isfield(opts,'maxitr')
    opts.maxitr = 100;
end
if ~isfield(opts,'beta')
    opts.beta = 5;
end

if ~isfield(opts,'gamma')
    opts.gamma = 1.25;
end
if ~isfield(opts,'relchg')
    opts.relchg = 1.e-3;
end
if ~isfield(opts,'print')
    opts.print = 0;
end






