function y = mtimes(a,x)
%function y = mtimes(a, x)
% y = G * x	 
% Copyright Jan. 25, 2008, Dr.WEN You-Wei
% email: wenyouwei@graduate.hku.hk
if ~isa(a, 'BlurMatrix') 
    if numel(a) ~= 1
        error('Wrong, the first paramter must be a scalar or a class of BlurMatrix');
    else
        y = x;
        y.eigblurmatrix = a * x.eigblurmatrix;
    end
    return;
end
if isa(x,'BlurMatrix')
    y = a;
    if a.imfiltertype == 0        
        y.eigblurmatrix = y.eigblurmatrix .* x.eigblurmatrix;
    else
        y.eigblurmatrix = conv2(y.eigblurmatrix, x.eigblurmatrix);
    end
    return;
end

if numel(x) == 1
    y = a;
    y.eigblurmatrix = y.eigblurmatrix  * x;
else
    if a.imfiltertype == 1
        [n, m, r] = size(a.eigblurmatrix);
        for j = 1:r
            h = a.eigblurmatrix;
            y(:,:,j) = imfilter(x(:,:,j), h(:,:,j),'same',a.boundarycond);
        end
        return;
    end
    
    switch a.boundarycond
        case {'cir','circular'}
            for k = 1:size(a.psf,3)
                y(:,:,k) = ifft2((a.eigblurmatrix(:,:,k)) .* (fft2(x(:,:,k))));
                y(:,:,k) = real(y(:,:,k));
            end
        case {'refl','symmetric'}
            for k = 1:size(a.psf,3)
                y(:,:,k) = idct2((a.eigblurmatrix(:,:,k)) .* dct2(x(:,:,k)));
            end
            
    end
end