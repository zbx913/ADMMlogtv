function ob = ctranspose(ob)
% Copyright Jan. 25, 2008, Dr.WEN You-Wei
% email: wenyouwei@graduate.hku.hk


if ob.imfiltertype == 0
    ob.eigblurmatrix = conj(ob.eigblurmatrix);
else
    ob.eigblurmatrix = ob.eigblurmatrix(end:-1:1, end:-1:1);
end
    
return;    
switch ob.boundarycond
    case {'cir', 'refl'}
        ob.eigblurmatrix = conj(ob.eigblurmatrix);
    case 'imfilter'
        ob.eigblurmatrix = ob.eigblurmatrix(end:-1:1, end:-1:1); 
    otherwise
        disp('Unknow method');
end
        
