function ob = conj(ob)
% Copyright Jan. 25, 2008, Dr.WEN You-Wei
% email: wenyouwei@graduate.hku.hk



ob.eigblurmatrix = conj(ob.eigblurmatrix);

