function c = rdivide(a,b)
% Copyright Jan. 25, 2008, Dr.WEN You-Wei
% email: wenyouwei@graduate.hku.hk

if isa(a,'BlurMatrix')
    if isa(b,'BlurMatrix')
        t = (a.eigblurmatrix) ./ (b.eigblurmatrix) ;
        c.eigblurmatrix = t;
    else
        c = (a.eigblurmatrix) ./ b;
    end
else
    c = a ./ (b.eigblurmatrix) ;
end
return;
