function y = ldivide(a,b)
% To calculate a.\b.
% Copyright Jan. 25, 2008, Dr.WEN You-Wei
% email: wenyouwei@graduate.hku.hk

if ~isa(a,'BlurMatrix')
    error('the first parameter must be the class of BlurMatrix');
end

if isa(b,'BlurMatrix')
	y = b;
	y.eigblurmatrix = a.eigblurmatrix .\ b.eigblurmatrix;
else
    y = a.eigblurmatrix .\ b;
    
end
